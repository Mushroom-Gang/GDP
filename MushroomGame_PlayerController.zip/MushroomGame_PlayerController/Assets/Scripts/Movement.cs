﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed = 1f;
    [SerializeField] private float jumpForce = 1f;
    [SerializeField] private float hangTime = .2f;
    [SerializeField] private float jumpBufferLength = .1f;

    public Transform camTarget;
    public float aheadAmount;
    public float aheadSpeed;

    private bool isGrounded;
    private float hangCounter;
    private float jumpBufferCount;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        moveHorizontally();
        jump();
        cameraAhead();
    }

    private void moveHorizontally()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");

        //Stop immediately after releasing Movement Buttons
        if (horizontal == 0)
        {
            rb.velocity = new Vector2(0, rb.velocity.y);
        }

        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
    }

    private void jump()
    {
        //Hang Time
        if(isGrounded == true)
        {
            hangCounter = hangTime;
        } else
        {
            hangCounter -= Time.deltaTime;
        }

        //Jump Buffer
        if (Input.GetButtonDown("Jump"))
        {
            jumpBufferCount = jumpBufferLength;
        } else
        {
            jumpBufferCount -= Time.deltaTime;
        }

        //Apply Jump Velocity
        if (jumpBufferCount >= 0 && hangCounter > 0f)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            jumpBufferCount = 0;
            isGrounded = false;
        }
        if(Input.GetButtonUp("Jump") && rb.velocity.y > 0)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * .2f);
        }
    }

    private void cameraAhead()
    {
        if(Input.GetAxisRaw("Horizontal") != 0)
        {
            camTarget.localPosition = new Vector3(Mathf.Lerp(camTarget.localPosition.x, aheadAmount * Input.GetAxisRaw("Horizontal"), aheadSpeed * Time.deltaTime), camTarget.localPosition.y, camTarget.localPosition.z);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            isGrounded = true;
        }
    }
}
